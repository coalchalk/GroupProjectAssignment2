cmake_minimum_required(VERSION 3.16)

project(CE4703Assignment2 LANGUAGES C)

add_executable(CE4703Assignment2 main.c
    doublelinkedlist.c
    orderedintset.c
    doublelinkedlist.h
    orderedintset.h
)

include(GNUInstallDirs)
install(TARGETS CE4703Assignment2
    LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
    RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
)
